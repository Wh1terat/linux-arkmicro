TEMPLATE = subdirs
SUBDIRS += localstorage
